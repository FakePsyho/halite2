// Author: Psyho
// Blog: http://psyho.gg/
// Twitter: https://twitter.com/fakepsyho

#include "hlt/hlt.hpp"
#include "hlt/navigation.hpp"
#include <bits/stdc++.h>
#include <sys/time.h>

using namespace std;
using namespace hlt;
using namespace hlt::navigation;

#define INLINE   inline __attribute__ ((always_inline))
#define NOINLINE __attribute__ ((noinline))

#define ALIGNED __attribute__ ((aligned(16)))

#define likely(x)   __builtin_expect(!!(x),1)
#define unlikely(x) __builtin_expect(!!(x),0)

#define SSELOAD(a)     _mm_load_si128((__m128i*)&a)
#define SSESTORE(a, b) _mm_store_si128((__m128i*)&a, b)

#define FOR(i,a,b)  for(int i=(a);i<(b);++i)
#define REP(i,a)    FOR(i,0,a)
#define ZERO(m)     memset(m,0,sizeof(m))
#define ALL(x)      x.begin(),x.end()
#define PB          push_back
#define S           size()
#define byte        unsigned char
#define LL          long long
#define ULL         unsigned long long
#define LD          long double
#define MP          make_pair
#define X           first
#define Y           second
#define VC          vector
#define PII         pair<int, int>
#define PDD         pair<double, double>
#define VI          VC<int>
#define VVI         VC<VI>
#define VVVI        VC<VVI>
#define VPII        VC<PII>
#define VVPII       VC<VPII>
#define VVVPII      VC<VVPII>
#define VD          VC<double>
#define VVD         VC<VD>
#define VVVD        VC<VVD>
#define VPDD        VC<PDD>
#define VVPDD       VC<VPDD>
#define VVVPDD      VC<VVPDD>
#define VS          VC<string>
#define VVS         VC<VS>
#define VVVS        VC<VVS>
#define DB(a)       cerr << #a << ": " << (a) << endl;

#define INF         1e9

template<class A, class B> ostream& operator<<(ostream &os, pair<A,B> &p) {os << "(" << p.X << "," << p.Y << ")"; return os;}
template<class A, class B, class C> ostream& operator<<(ostream &os, tuple<A,B,C> &p) {os << "(" << get<0>(p) << "," << get<1>(p) << "," << get<2>(p) << ")"; return os;}
template<class T> ostream& operator<<(ostream &os, VC<T> &v) {os << "{"; REP(i, v.S) {if (i) os << ", "; os << v[i];} os << "}"; return os;}
template<class T> ostream& operator<<(ostream &os, set<T> &s) {VC<T> vs(ALL(s)); return os << vs;}
template<class A, class B> ostream& operator<<(ostream &os, map<A, B> &m) {VC<pair<A,B>> vs; for (auto &x : m) vs.PB(x); return os << vs;}
template<class T> string i2s(T x) {ostringstream o; if (floor(x) == x) o << (int)x; else o << x; return o.str();}
VS splt(string s, char c = ' ') {VS all; int p = 0, np; while (np = s.find(c, p), np >= 0) {all.PB(s.substr(p, np - p)); p = np + 1;} all.PB(s.substr(p)); return all;}

double getTime() {
	timeval tv;
	gettimeofday(&tv, NULL);
	return tv.tv_sec + tv.tv_usec * 1e-6;
}

struct RNG {
    unsigned int MT[624];
    int index;
	
	RNG(int seed = 1) {
		init(seed);
	}
    
    void init(int seed = 1) {
        MT[0] = seed;
        FOR(i, 1, 624) MT[i] = (1812433253UL * (MT[i-1] ^ (MT[i-1] >> 30)) + i);
        index = 0;
    }
    
    void generate() {
        const unsigned int MULT[] = {0, 2567483615UL};
        REP(i, 227) {
            unsigned int y = (MT[i] & 0x8000000UL) + (MT[i+1] & 0x7FFFFFFFUL);
            MT[i] = MT[i+397] ^ (y >> 1);
            MT[i] ^= MULT[y&1];
        }
        FOR(i, 227, 623) {
            unsigned int y = (MT[i] & 0x8000000UL) + (MT[i+1] & 0x7FFFFFFFUL);
            MT[i] = MT[i-227] ^ (y >> 1);
            MT[i] ^= MULT[y&1];
        }
        unsigned int y = (MT[623] & 0x8000000UL) + (MT[0] & 0x7FFFFFFFUL);
        MT[623] = MT[623-227] ^ (y >> 1);
        MT[623] ^= MULT[y&1];
    }
    
    unsigned int rand() {
        if (index == 0) {
            generate();
        }
        
        unsigned int y = MT[index];
        y ^= y >> 11;
        y ^= y << 7  & 2636928640UL;
        y ^= y << 15 & 4022730752UL;
        y ^= y >> 18;
        index = index == 623 ? 0 : index + 1;
        return y;
    }
    
    INLINE int next() {
        return rand();
    }
    
    INLINE int next(int x) {
        return rand() % x;
    }
    
    INLINE int next(int a, int b) {
        return a + (rand() % (b - a));
    }
    
    INLINE double nextDouble() {
        return (rand() + 0.5) * (1.0 / 4294967296.0);
    }
};

PlayerId player_id;
Map m;

bool expected_collision(Move &m1, Move &m2, int steps = 100) {
	const double COLLISION_DIST = 1.15;
	const Ship& s1 = m.get_ship(player_id, m1.ship_id);
	const Ship& s2 = m.get_ship(player_id, m2.ship_id);
	double d = s1.location.get_distance_to(s2.location);
	if (d > 17) return false;
	if (d > m1.move_thrust + m2.move_thrust + 3) return false;
	double rad1 = m1.move_angle_deg / 180.0 * M_PI;
	double rad2 = m2.move_angle_deg / 180.0 * M_PI;
	double vx1 = m1.move_thrust * cos(rad1);
	double vy1 = m1.move_thrust * sin(rad1);
	double vx2 = m2.move_thrust * cos(rad2);
	double vy2 = m2.move_thrust * sin(rad2);
	FOR(step, 1, steps+1) {
		double ratio = 1.0 * step / steps;
		double x1 = s1.location.pos_x + vx1 * ratio;
		double y1 = s1.location.pos_y + vy1 * ratio;
		double x2 = s2.location.pos_x + vx2 * ratio;
		double y2 = s2.location.pos_y + vy2 * ratio;
		if ((x1-x2)*(x1-x2)+(y1-y2)*(y1-y2) < COLLISION_DIST * COLLISION_DIST) {
			return true;
		}
	}
	return false;
}

int getShipId(int player_id, EntityId ship_id) {
	return player_id * 12345678 + (int)ship_id;
}

map<EntityId, int> planetMyShips;
map<EntityId, int> planetEnemyShips;
set<int> aggressiveShips;
map<EntityId, double> planetValue;
bool holdCorners[2][2];
map<EntityId, bool> shipUsed;
map<int, int> enemyFollowers;
map<int, Ship*> enemyShips;
int turn = 0;

enum OrderType {
	Unknown = 0,
	Invalid = 1,
	Colonize = 2,
	AttackShip = 3,
	AttackMiner = 4,
	Hide = 5,
};

struct Order {
	OrderType type;
	double value;
	Move move;
	EntityId ship;
	EntityId planet;
	int target;
	int cornerx;
	int cornery;
	
	Order() {
		type = OrderType::Unknown;
		value = -INF;
		move = Move::noop();
		ship = -1;
		target = -1;
		planet = -1;
		cornerx = -1;
		cornery = -1;
	}
	
	string tostring() {
		string s = "[Order] Ship: " + i2s((int)ship) + " Value: " + i2s(value) + " Type: ";
		if (type == OrderType::Unknown) {
			s += "Unknown";
		} else if (type == OrderType::Invalid) {
			s += "Invalid";
		} else if (type == OrderType::Colonize) {
			s += "Colonize Planet: " + i2s((int)planet);
		} else if (type == OrderType::AttackShip) {
			s += "AttackShip";
		} else if (type == OrderType::AttackMiner) {
			s += "AttackMiner";
		} else if (type == OrderType::Hide) {
			s += "Hide At: " + i2s(cornerx) + "," + i2s(cornery);
		}
		return s;
	}
};

Order colonizeOrder(const Ship& ship, const Planet& planet) {
	Order o;
	o.type = OrderType::Colonize;
	o.ship = ship.entity_id;
	o.planet = planet.entity_id;
	
	if (planetEnemyShips[planet.entity_id] > 0) return o;
	if (planetMyShips[planet.entity_id] >= planet.docking_spots) return o;
	
	if (ship.can_dock(planet)) {
		o.value = 2500;
	} else {
		o.value = 2000 - ship.location.get_distance_to(planet.location) + planetValue[planet.entity_id];
	}
	
	return o;
}

Order attackOrder(const Ship& ship, const Ship& eship, int eid, double minValue = 0) {
	Order o;
	if (enemyFollowers[eid] >= 5 || enemyFollowers[eid] >= 3 && turn < 60) return o;
	
	double dist = ship.location.get_distance_to(eship.location);
	double v = 1000 - dist;
	if (dist < 30) v += 2000;
	if (aggressiveShips.count(eid)) v += 15;
	if (eship.docking_status != ShipDockingStatus::Undocked) v += 40;
	
	if (v <= minValue) return o;
	if (!navigate_ship_towards_target(m, ship, eship.location, 0.0, true, constants::MAX_NAVIGATION_CORRECTIONS, M_PI / 180.0).Y) return o;
	
	o.ship = ship.entity_id;
	o.target = eid;
	o.type = eship.docking_status == ShipDockingStatus::Undocked ? OrderType::AttackShip : OrderType::AttackMiner;
	o.value = v;
	return o;
}

Order hideOrder(const Ship& ship, int cx, int cy) {
	Location loc(cx == 0 ? 1 : m.map_width - 1, cy == 0 ? 1 : m.map_height - 1);
	double dist = ship.location.get_distance_to(loc);
	
	Order o;
	o.ship = ship.entity_id;
	o.cornerx = cx;
	o.cornery = cy;
	o.type = OrderType::Hide;
	o.value = 5000 - dist;
	return o;
}

void recalcOrder(Order& o) {
	const Ship& ship = m.get_ship(player_id, o.ship);
	if (o.type == OrderType::Colonize) {
		o = colonizeOrder(ship, m.planets[o.planet]);
	} else if (o.type == OrderType::AttackShip || o.type == OrderType::AttackMiner) {
		Ship eship = *enemyShips[o.target];
		o = attackOrder(ship, eship, o.target);
	} else if (o.type == OrderType::Hide) {
		o = hideOrder(ship, o.cornerx, o.cornery);
	} else {
		assert(false);
	}
}

Move execOrder(Order &o) {
	const Ship& ship = m.get_ship(player_id, o.ship);
	
	if (o.type == OrderType::Colonize) {
		Planet& planet = m.planets[o.planet];
		if (ship.can_dock(planet)) {
			Move m = Move::dock(ship.entity_id, planet.entity_id);
			m.evasion = Evasion::None;
			return m;
		} else {
			auto nav = navigate_ship_to_dock(m, ship, planet, constants::MAX_SPEED);
			Move m = nav.Y ? nav.X : Move::stop(ship.entity_id);
			m.evasion = Evasion::None;
			return m;
		}
		
	} else if (o.type == OrderType::AttackShip) {
		Ship eship = *enemyShips[o.target];
		double dist = ship.location.get_distance_to(eship.location);
		auto nav = navigate_ship_towards_target(m, ship, eship.location, max(0.0, min(dist - 0, constants::MAX_SPEED)), true, constants::MAX_NAVIGATION_CORRECTIONS, M_PI / 180.0);
		Move m = nav.Y ? nav.X : Move::stop(ship.entity_id);
		m.evasion = Evasion::Small;
		return m;
		
	} else if (o.type == OrderType::AttackMiner) {
		Ship eship = *enemyShips[o.target];
		double dist = ship.location.get_distance_to(eship.location);
		auto nav = navigate_ship_towards_target(m, ship, eship.location, max(0.0, min(dist - 1.25, constants::MAX_SPEED)), true, constants::MAX_NAVIGATION_CORRECTIONS, M_PI / 180.0);
		Move m = nav.Y ? nav.X : Move::stop(ship.entity_id);
		m.evasion = Evasion::Medium;
		return m;
		
	} else if (o.type == OrderType::Hide) {
		Location loc = Location(o.cornerx == 0 ? 1 : m.map_width - 1, o.cornery == 0 ? 1 : m.map_height - 1);
		double dist = ship.location.get_distance_to(loc);
		auto nav = navigate_ship_towards_target(m, ship, loc, min(dist, constants::MAX_SPEED), true, constants::MAX_NAVIGATION_CORRECTIONS, M_PI / 180.0);
		Move m = nav.Y ? nav.X : Move::stop(ship.entity_id);
		m.evasion = Evasion::Full;
		return m;
		
	} else {
		assert(false);
	}
}

int main() {
	const bool LOG_MOVES = false;
	
	ios_base::sync_with_stdio(false);
    const Metadata metadata = initialize("Psyho");
    player_id = metadata.player_id;

    const Map& initial_map = metadata.initial_map;

    ostringstream initial_map_intelligence;
    initial_map_intelligence
            << "width: " << initial_map.map_width
            << "; height: " << initial_map.map_height
            << "; players: " << initial_map.ship_map.size()
            << "; my ships: " << initial_map.ship_map.at(player_id).size()
            << "; planets: " << initial_map.planets.size();
    Log::log(initial_map_intelligence.str());

	turn = 0;
	while (true) {
		double startTime = getTime();
		turn++;
		
        m = in::get_map();
		
		int players_no = m.ships.S;
		
		//Create enemyShips map
		enemyShips.clear();
		for (auto& ps : m.ships) for (Ship& ship : ps.Y) enemyShips[getShipId(ps.X, ship.entity_id)] = &ship;
		
		//Calc Aggressive Units
		aggressiveShips.clear();
		for (Ship& ship : m.ships[player_id]) if (ship.docking_status != ShipDockingStatus::Undocked) {
			for (auto ps : m.ships) if (ps.X != player_id) for (Ship& eship : ps.Y) if (eship.docking_status == ShipDockingStatus::Undocked) {
				if (ship.location.get_distance_to(eship.location) < 25)
					aggressiveShips.insert(getShipId(ps.X, eship.entity_id));
			}
		}
		
		//Calc MyShips & EnemyShips
		planetMyShips.clear();
		planetEnemyShips.clear();
		for (auto& ps : m.ships) for (Ship& ship : ps.Y) {
			if (ship.docking_status == ShipDockingStatus::Undocked) continue;
			EntityId planetId = ship.docked_planet;
			if (ps.X == player_id) {
				planetMyShips[planetId]++;
			} else {
				planetEnemyShips[planetId]++;
			}
		}
		
		//Calc Planet Value
		planetValue.clear();
		if (players_no > 2) {
			Location centerMass;
			int planetsOwned = 0;
			for (Planet& p : m.planets) if (p.owned) {
				centerMass += p.location;
				planetsOwned++;
			}
			if (planetsOwned) centerMass /= planetsOwned;
			
			for (Planet& p : m.planets) {
				double v = 0;
				
				double dist_from_origin = Location(m.map_width / 2, m.map_height / 2).get_distance_to(p.location);
				v += dist_from_origin * 0.1;
				
				double dist_from_mass_center = planetsOwned ? p.location.get_distance_to(centerMass) : 0.0;
				v -= dist_from_mass_center * 0.1;
				
				// double dist_to_enemy = 1e9;
				// for (Planet& p2 : m.planets) if (planetEnemyShips[p2.entity_id] > 0)
					// dist_to_enemy = min(dist_to_enemy, p.location.get_distance_to(p2.location));
				// if (dist_to_enemy > 1e6) dist_to_enemy = 0;
				// v += dist_to_enemy * 0.3;
				
				planetValue[p.entity_id] = v;
			}
		}
		
		//Calc Going Down
		bool goingDown = false;
		ZERO(holdCorners);
		int totalShips = 0;
		for (auto& ps : m.ships) totalShips += ps.Y.S;
		if (players_no > 2 && turn > 40 && m.ships[player_id].S < totalShips * 0.1) goingDown = true;
		
		
		//Generate Orders
		shipUsed.clear();
		enemyFollowers.clear();
		VC<Order> orders;
		VC<Order> so(m.ships[player_id].S);
		Log::log("[Phase Start] Orders");
		
		int ordersSaved = 0;
		int ordersCalced = 0;
		while (true) {
			bool late = getTime() - startTime > 1.0;
			
			Order bo;
			bo.type = OrderType::Invalid;
			bo.value = 0;
			
			REP(i, m.ships[player_id].S) {
				Ship& ship = m.ships[player_id][i];
				if (shipUsed[ship.entity_id]) continue;
				if (ship.docking_status != ShipDockingStatus::Undocked)	continue;
				
				if (!late && so[i].value > 0) {
					double prevValue = so[i].value;
					recalcOrder(so[i]);
					if (prevValue == so[i].value) {
						ordersSaved++;
						if (so[i].value > bo.value)
							bo = so[i];
						continue;
					} 
				}
				ordersCalced++;
				so[i] = Order();
				
				for (Planet& planet : m.planets) {
					Order o = colonizeOrder(ship, planet);
					if (o.value > so[i].value)
						so[i] = o;
				}
				
				
				for (auto ps : m.ships) if (ps.X != player_id) for (Ship& eship : ps.Y) {
					Order o = attackOrder(ship, eship, getShipId(ps.X, eship.entity_id), so[i].value);
					if (o.value > so[i].value)
						so[i] = o;
				}
				
				if (goingDown) REP(cx, 2) REP(cy, 2) if (!holdCorners[cx][cy]) {
					Order o = hideOrder(ship, cx, cy);
					if (o.value > so[i].value)
						so[i] = o;
				}
				
				if (late) {
					bo = so[i];
					orders.PB(bo);
					shipUsed[bo.ship] = true;
					if (bo.planet >= 0) planetMyShips[bo.planet]++;
					if (bo.target >= 0) enemyFollowers[bo.target]++;
					if (bo.cornerx >= 0) holdCorners[bo.cornerx][bo.cornery] = true;
				}
				
				if (so[i].value > bo.value)
					bo = so[i];
			}
			
			if (bo.type == OrderType::Invalid)
				break;
			
			orders.PB(bo);
			shipUsed[bo.ship] = true;
			if (bo.planet >= 0) planetMyShips[bo.planet]++;
			if (bo.target >= 0) enemyFollowers[bo.target]++;
			if (bo.cornerx >= 0) holdCorners[bo.cornerx][bo.cornery] = true;
			if (late) break;
		}
		
		Log::log("Orders Saved: " + i2s(ordersSaved));
		Log::log("Orders Calced: " + i2s(ordersCalced));
		
		VC<Move> moves;
		for (Order &o : orders) {
			Move mv = execOrder(o);
			moves.PB(mv);
			if (LOG_MOVES) {
				Location loc = m.get_ship(player_id, mv.ship_id).location;
				Log::log("[Order] " + o.tostring() +  " [Move] Type: " + i2s((int)mv.type) + " Evasion: " + i2s((int)mv.evasion) + " Thrust: " + i2s(mv.move_thrust) + " Angle: " + i2s(mv.move_angle_deg) + " PosX: " + i2s(loc.pos_x) + " PosY: " + i2s(loc.pos_y));
			}
		}
		
		//Evasion
		Log::log("[Phase Start] Evasion");
		REP(i, moves.S) {
			if (moves[i].type != MoveType::Thrust) continue;
			if (moves[i].evasion == Evasion::None) continue;
			
			const Ship& ship = m.get_ship(player_id, moves[i].ship_id);
			int allies = 0;
			int enemies = 0;
			double ex = 0;
			double ey = 0;
			
			Location loc = ship.location;
			Location tloc = loc + moves[i].get_velocity() / 2;
			
			double closest_enemy = 1e9;
			for (auto ps : m.ships) for (Ship& eship : ps.Y) if (eship.entity_id != ship.entity_id || ps.X != player_id) {
				if (eship.docking_status != ShipDockingStatus::Undocked) continue;
				Location eloc = eship.location;
				double distance = loc.get_distance_to(eloc);
				double target_distance = tloc.get_distance_to(eloc);
				if (distance < 12.5 && ps.X == player_id) {
					allies++;
				} else if (target_distance < 12.5 && ps.X != player_id) {
					enemies++;
					closest_enemy = min(closest_enemy, ship.location.get_distance_to(eship.location));
					ex += eship.location.pos_x;
					ey += eship.location.pos_y;
				}
			}
			
			
			if (enemies > allies+1 || enemies > allies && moves[i].evasion == Evasion::Medium || enemies > 0 && moves[i].evasion == Evasion::Full) {
				ex /= enemies;
				ey /= enemies;
				double dx = ship.location.pos_x - ex;
				double dy = ship.location.pos_y - ey;
				double dd = sqrt(dx*dx + dy*dy + 1e-3);
				dx /= dd;
				dy /= dd;
				Location tloc = Location((int)(ship.location.pos_x + dx * 10 + 0.5), (int)(ship.location.pos_y + dy * 10 + 0.5));
				double speed = max(0.0, min(1.0 * constants::MAX_SPEED, 15 - dd));
				if (moves[i].evasion == Evasion::Full) speed = constants::MAX_SPEED;
				// speed = constants::MAX_SPEED;
				auto move = navigate_ship_towards_target(m, ship, tloc, speed, true, constants::MAX_NAVIGATION_CORRECTIONS, M_PI / 180.0);
				// auto move = navigate_ship_towards_target(m, ship, tloc, constants::MAX_SPEED, true, constants::MAX_NAVIGATION_CORRECTIONS, M_PI / 180.0);
				if (move.Y) {
					Log::log("Evade: " + i2s(moves[i].ship_id));
					moves[i] = move.X;
				}
			}
		}
		
		//Avoid Exiting Map
		Log::log("[Phase Start] Avoid OoB");
		REP(i, moves.S) {
			if (moves[i].type != MoveType::Thrust) continue;
			
			if (moves[i].evasion == Evasion::None || moves[i].evasion == Evasion::Small) {
				while (moves[i].move_thrust > 0) {
					Location loc = m.get_ship(player_id, moves[i].ship_id).location;
					loc += moves[i].get_velocity();
					if (m.in_bounds(loc)) break;
					moves[i].move_thrust--;
					Log::log("Map Bounds");
				}
			} else {
				Move mc = moves[i];
				Location bloc = m.get_ship(player_id, moves[i].ship_id).location;
				if (m.in_bounds(bloc + mc.get_velocity())) continue;
				int bdiff = -100;
				FOR(diff, -90, +90) {
					mc.move_angle_deg = moves[i].move_angle_deg + diff;
					Location loc = bloc + mc.get_velocity();
					if (m.in_bounds(loc)) {
						if (abs(diff) < abs(bdiff)) bdiff = diff;
					}
				}
				moves[i].move_angle_deg = moves[i].move_angle_deg + 360 + bdiff;
				while (moves[i].move_angle_deg >= 360) moves[i].move_angle_deg -= 360;
			}
		}
		
		//Anti-collision post process
		Log::log("Phase: Anti-Collision!");
		int total_collisions_avoided = 0;
		REP(i, moves.S) {
			if (getTime() - startTime > 1.5) break;
			
			if (moves[i].type != MoveType::Thrust) continue;
			if (moves[i].move_thrust == 0) continue;
			bool first = true;
			while (moves[i].move_thrust > 0) {
				bool succ = true;
				REP(j, i) {
					if (expected_collision(moves[i], moves[j])) {
						if (first) total_collisions_avoided++, first = false;
						moves[i].move_thrust = max(0.0, moves[i].move_thrust - 1);
						succ = false;
						break;
					}
				}
				if (succ) break;
			}
		}
		if (total_collisions_avoided)
			Log::log("Total Collisions Avoided: " + i2s(total_collisions_avoided));
		
		Log::log("Total Moves: " + i2s(moves.S));
		
		Log::log("[Done]");
        if (!out::send_moves(moves)) {
            Log::log("send_moves failed; exiting");
            break;
        }
    }
}
