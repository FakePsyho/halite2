// Author: Psyho
// Blog: http://psyho.gg/
// Twitter: https://twitter.com/fakepsyho

#include "hlt/hlt.hpp"
#include "hlt/navigation.hpp"
#include <bits/stdc++.h>
#include <sys/time.h>

using namespace std;
using namespace hlt;
using namespace hlt::navigation;
using namespace hlt::collision;
using namespace hlt::constants;

const bool LOG_MOVES = true;
const bool GIVE_UP_LOSING = false;	

#define INLINE   inline __attribute__ ((always_inline))
#define NOINLINE __attribute__ ((noinline))

#define ALIGNED __attribute__ ((aligned(16)))

#define likely(x)   __builtin_expect(!!(x),1)
#define unlikely(x) __builtin_expect(!!(x),0)

#define SSELOAD(a)     _mm_load_si128((__m128i*)&a)
#define SSESTORE(a, b) _mm_store_si128((__m128i*)&a, b)

#define FOR(i,a,b)  for(int i=(a);i<(b);++i)
#define REP(i,a)    FOR(i,0,a)
#define ZERO(m)     memset(m,0,sizeof(m))
#define ALL(x)      x.begin(),x.end()
#define PB          push_back
#define S           size()
#define byte        unsigned char
#define LL          long long
#define ULL         unsigned long long
#define LD          long double
#define MP          make_pair
#define X           first
#define Y           second
#define VC          vector
#define PII         pair<int, int>
#define PDD         pair<double, double>
#define VI          VC<int>
#define VVI         VC<VI>
#define VVVI        VC<VVI>
#define VPII        VC<PII>
#define VVPII       VC<VPII>
#define VVVPII      VC<VVPII>
#define VD          VC<double>
#define VVD         VC<VD>
#define VVVD        VC<VVD>
#define VPDD        VC<PDD>
#define VVPDD       VC<VPDD>
#define VVVPDD      VC<VVPDD>
#define VS          VC<string>
#define VVS         VC<VS>
#define VVVS        VC<VVS>
#define DB(a)       cerr << #a << ": " << (a) << endl;

#define INF         1e9

template<class A, class B> ostream& operator<<(ostream &os, pair<A,B> &p) {os << "(" << p.X << "," << p.Y << ")"; return os;}
template<class A, class B, class C> ostream& operator<<(ostream &os, tuple<A,B,C> &p) {os << "(" << get<0>(p) << "," << get<1>(p) << "," << get<2>(p) << ")"; return os;}
template<class T> ostream& operator<<(ostream &os, VC<T> &v) {os << "{"; REP(i, v.S) {if (i) os << ", "; os << v[i];} os << "}"; return os;}
template<class T> ostream& operator<<(ostream &os, set<T> &s) {VC<T> vs(ALL(s)); return os << vs;}
template<class A, class B> ostream& operator<<(ostream &os, map<A, B> &m) {VC<pair<A,B>> vs; for (auto &x : m) vs.PB(x); return os << vs;}
template<class T> string i2s(T x) {ostringstream o; if (floor(x) == x) o << (int)x; else o << x; return o.str();}
VS splt(string s, char c = ' ') {VS all; int p = 0, np; while (np = s.find(c, p), np >= 0) {all.PB(s.substr(p, np - p)); p = np + 1;} all.PB(s.substr(p)); return all;}

double getTime() {
	timeval tv;
	gettimeofday(&tv, NULL);
	return tv.tv_sec + tv.tv_usec * 1e-6;
}

struct Timer {
	double total = 0;
	double startTime;
	bool running = false;
	string name = "";
	
	Timer(string _name = "") {
		name = _name;
	}
	
	void start() {
		startTime = getTime();
		running = true;
	}
	
	void stop() {
		total += getTime() - startTime;
		running = false;
	}
	
	double elapsed() {
		return total + (running ? getTime() - startTime : 0);
	}
	
	string tostring() {
		return "Timer" + (name.S ? string(" ") + name : string("")) + ": " + i2s(elapsed());
	}
};

VC<Timer*> timerPool;
#define ADD_TIMER(name) Timer timer##name(#name); timerPool.PB(&timer##name);

struct RNG {
    unsigned int MT[624];
    int index;
	
	RNG(int seed = 1) {
		init(seed);
	}
    
    void init(int seed = 1) {
        MT[0] = seed;
        FOR(i, 1, 624) MT[i] = (1812433253UL * (MT[i-1] ^ (MT[i-1] >> 30)) + i);
        index = 0;
    }
    
    void generate() {
        const unsigned int MULT[] = {0, 2567483615UL};
        REP(i, 227) {
            unsigned int y = (MT[i] & 0x8000000UL) + (MT[i+1] & 0x7FFFFFFFUL);
            MT[i] = MT[i+397] ^ (y >> 1);
            MT[i] ^= MULT[y&1];
        }
        FOR(i, 227, 623) {
            unsigned int y = (MT[i] & 0x8000000UL) + (MT[i+1] & 0x7FFFFFFFUL);
            MT[i] = MT[i-227] ^ (y >> 1);
            MT[i] ^= MULT[y&1];
        }
        unsigned int y = (MT[623] & 0x8000000UL) + (MT[0] & 0x7FFFFFFFUL);
        MT[623] = MT[623-227] ^ (y >> 1);
        MT[623] ^= MULT[y&1];
    }
    
    unsigned int rand() {
        if (index == 0) {
            generate();
        }
        
        unsigned int y = MT[index];
        y ^= y >> 11;
        y ^= y << 7  & 2636928640UL;
        y ^= y << 15 & 4022730752UL;
        y ^= y >> 18;
        index = index == 623 ? 0 : index + 1;
        return y;
    }
    
    INLINE int next() {
        return rand();
    }
    
    INLINE int next(int x) {
        return rand() % x;
    }
    
    INLINE int next(int a, int b) {
        return a + (rand() % (b - a));
    }
    
    INLINE double nextDouble() {
        return (rand() + 0.5) * (1.0 / 4294967296.0);
    }
	
    INLINE double nextDouble(double a, double b) {
        return nextDouble() * (b - a) + a;
    }
};

RNG rng(1);

PlayerId player_id;
Map m;

map<EntityId, double> closestEnemyShip;
map<EntityId, int> planetAllies;
map<EntityId, int> planetEnemies;
map<EntityId, int> maxFollowers;
map<EntityId, int> enemyFollowers;
map<EntityId, int> planetMyShips;
map<EntityId, int> planetEnemyShips;
map<int, EntityId> aggressiveShips;
map<EntityId, double> planetValue;
bool holdCorners[2][2];
map<EntityId, bool> shipUsed;
map<int, int> minerDefenders;
map<int, Ship*> enemyShips;
VC<pair<Location, PlayerId>> spawnedShips;
int turn = 0;

const int MASK_PLANETS = 1;
const int MASK_ALLIES = 2;
const int MASK_ALLIES_DOCKED = 4;
const int MASK_ENEMIES = 8;
const int MASK_ENEMIES_DOCKED = 16;
const int MASK_ALL = 31;

VC<Entity> findCloseEntities(Location loc, double radius, int mask = MASK_ALL, EntityId ship_id = -1) {
	VC<Entity> rv;
	if (mask & MASK_PLANETS) for (Planet& p : m.planets) if (loc.dist(p.location) < radius + p.radius) rv.PB(p);
	if (mask & MASK_ALLIES) for (Ship& s : m.ships[player_id]) if (s.entity_id != ship_id && loc.dist(s.location) < radius && !s.docked()) rv.PB(s);
	if (mask & MASK_ALLIES_DOCKED) for (Ship& s : m.ships[player_id]) if (s.entity_id != ship_id && loc.dist(s.location) < radius && s.docked()) rv.PB(s);
	if (mask & MASK_ENEMIES) for (auto& ps : m.ships) if (ps.X != player_id) for (Ship& s : ps.Y) if (!s.docked() && loc.dist(s.location) < radius) rv.PB(s);
	if (mask & MASK_ENEMIES_DOCKED) for (auto& ps : m.ships) if (ps.X != player_id) for (Ship& s : ps.Y) if (s.docked() && loc.dist(s.location) < radius) rv.PB(s);
	return rv;
}

int detectCollisions(const Location& start, const Location& end, VC<Entity>& entities, double radius = 0.525, bool earlyExit = true) {
	int rv = 0;
	for (auto& e : entities) 
		if (segment_circle_intersect(start, end, e, radius)) {
			if (earlyExit) return 1;
			rv++;
		}
	return rv;
}

int detectCollisions(const Location& start, double ang, double thrust, VC<Entity>& entities, double radius = 0.525, bool earlyExit = true) {
	Location end = start + Move::get_velocity(ang, thrust);
	return detectCollisions(start, end, entities, radius, earlyExit) + (m.in_bounds(end) ? 0 : 1);
}

Location getSpawningPoint(Planet& p) {
	Location bloc(-1e9, -1e9);
	Location origin(m.map_width / 2.0, m.map_height / 2.0);
	VC<Entity> entities = findCloseEntities(p.location, p.radius + 10, MASK_ALL);
	FOR(dx, -SPAWN_RADIUS, +SPAWN_RADIUS + 1) FOR(dy, -SPAWN_RADIUS, +SPAWN_RADIUS + 1) {
		double offset_angle = atan2(dy, dx);
		double offset_x = dx + p.radius * cos(offset_angle);
		double offset_y = dy + p.radius * sin(offset_angle);
		auto loc = p.location + Location(offset_x, offset_y);
		
		bool collision = false;
		for (Entity& e : entities) if (loc.dist(e.location) < SHIP_RADIUS * 4) {
			collision = true;
			break;
		}
		if (collision) continue;
		if (origin.dist_sq(loc) < origin.dist_sq(bloc)) bloc = loc;
	}
	return bloc;
}



double round_angle(double rad) {
	return util::angle_rad_to_deg_clipped(rad) / 180.0 * M_PI;
}

bool late = false;
Move move_to(const Ship& ship, const Location& target, double maxSpeed = MAX_SPEED, double radius = 0, bool avoidEnemies = false, bool cluster = false) {
	radius *= radius;
	VC<Entity> entities = findCloseEntities(ship.location, 16.0, MASK_PLANETS | MASK_ALLIES | MASK_ALLIES_DOCKED | MASK_ENEMIES_DOCKED, ship.entity_id);
	VC<Entity> enemies = avoidEnemies ? findCloseEntities(ship.location, 25.0, MASK_ENEMIES) : VC<Entity>();
	VC<Entity> allies = cluster ? findCloseEntities(ship.location, 30.0, MASK_ALLIES) : VC<Entity>();
	VC<Location> spawnedEnemies;
	if (avoidEnemies) {
		for (Entity& enemy : enemies) {
			enemy.move.move_thrust = min(ship.location.dist(enemy.location), MAX_SPEED);
			enemy.move.move_angle_deg = util::angle_rad_to_deg_clipped(enemy.location.orient_towards_in_rad(ship.location));
		}
		for (auto& spawn : spawnedShips) {
			if (spawn.Y != player_id && ship.location.dist(spawn.X) < 25.0) spawnedEnemies.PB(spawn.X);
		}
	}
	
	double ang = ship.location.get_angle(target);
	
	const int TOTAL_ANG_STEPS = 72;
	
	double bv = 1e9;
	double bang = 0;
	double bd2 = 0;
	double bthrust = -1;
	
	double bmin = 1e9;
	
	// if (radius == 0 && !avoidEnemies && !detectCollisions(ship.location, round_angle(ang), (int)maxSpeed, entities)) return Move::thrust_rad(ship.entity_id, (int)maxSpeed, round_angle(ang));
	
	REP(angStep, TOTAL_ANG_STEPS) {
		double nang = round_angle(ang + angStep * 2 * M_PI / TOTAL_ANG_STEPS);
		REP(nthrust, maxSpeed + 1e-9) {
			if (nthrust == 0 && angStep) continue;
			Location end = ship.location + Move::get_velocity(nang, nthrust);
			double d2 = target.dist_sq(end);
			double av = d2;
			if (radius) av = av < radius ? radius - av : 10000 + av;
			if (enemies.S == 0 && allies.S == 0 && av >= bv) continue;
			if (detectCollisions(ship.location, nang, nthrust, entities)) continue;
			double minDist = 1e9;
			if (enemies.S) {
				for (Entity& e : enemies) minDist = min(minDist, segment_circle_dist(ship.location, end, e));
				for (auto& loc : spawnedEnemies) minDist = min(minDist, end.dist(loc));
			}
			if (minDist < 1e5) {
				av = 10000;
				if (d2 >= radius) {
					av += 10000;
					av += sqrt(d2);
				} else {
					if (minDist < 6.25) av += 10000;
					av += sqrt(radius) - sqrt(d2);
				}
				if (minDist < 6.25) av += 20000;
				av -= min(9.0, minDist) * 4;
			}
			if (allies.S) {
				av -= sqrt(d2);
				for (Entity& e : allies) {
					av += 10 * sqrt(max(2.0, end.dist(e.location + e.move.get_velocity())));
				}
			}
				
			
			if (av < bv) {
				bmin = minDist;
				bd2 = d2;
				
				bv = av;
				bang = nang;
				bthrust = nthrust;
			}
		}
	}
	
	// if (avoidEnemies) {
		// Location end = ship.location + Move::get_velocity(bang, bthrust);
		// Log::log("Vel: " + Move::get_velocity(bang, bthrust).tostring());
		// Log::log("End: " + end.tostring());
		// Log::log("BV: " + i2s(bv) + " BMIN: " + i2s(bmin) + " BD2: " + i2s(bd2));
		// for (Entity& entity : entities) {
			// Log::log("Rad: " + i2s(entity.radius) + " Pos: " + entity.location.tostring() + " DistS: " + i2s(entity.location.dist(ship.location)) + " DistE: " + i2s(entity.location.dist(end)) + " Close: " + i2s(segment_circle_dist(ship.location, end, entity.location)));
		// }
		// for (auto& e : enemies) {
			// Log::log("Enemy: " + i2s((int)e.entity_id) + " Pos: " + e.location.tostring() + " DistSO: " + i2s(ship.location.dist(e.location)) + " Close: " + i2s(segment_circle_dist(ship.location, end, e)));
		// }
	// }
	
	return Move::thrust_rad(ship.entity_id, bthrust, bang);
}

enum OrderType {
	Unknown = 0,
	Invalid = 1,
	Colonize = 2,
	AttackShip = 3,
	AttackMiner = 4,
	DefendMiner = 5,
	HitAndRun = 6,
	Hide = 7,
};

struct Order {
	OrderType type;
	double value;
	Move move;
	EntityId ship;
	EntityId planet;
	EntityId target;
	int cornerx;
	int cornery;
	
	Order() {
		type = OrderType::Unknown;
		value = -INF;
		move = Move::noop();
		ship = -1;
		target = -1;
		planet = -1;
		cornerx = -1;
		cornery = -1;
	}
	
	string tostring() {
		string s = "[Order] Ship: " + i2s((int)ship) + " Value: " + i2s(value) + " Type: ";
		if (type == OrderType::Unknown) {
			s += "Unknown";
		} else if (type == OrderType::Invalid) {
			s += "Invalid";
		} else if (type == OrderType::Colonize) {
			s += "Colonize Planet: " + i2s((int)planet);
		} else if (type == OrderType::AttackShip) {
			s += "AttackShip";
		} else if (type == OrderType::AttackMiner) {
			s += "AttackMiner";
		} else if (type == OrderType::DefendMiner) {
			s += "DefendMiner";
		} else if (type == OrderType::HitAndRun) {
			s += "HitAndRun";
		} else if (type == OrderType::Hide) {
			s += "Hide At: " + i2s(cornerx) + "," + i2s(cornery);
		}
		return s;
	}
};

Order colonizeOrder(const Ship& ship, const Planet& planet) {
	Order o;
	o.type = OrderType::Colonize;
	o.ship = ship.entity_id;
	o.planet = planet.entity_id;
	
	if (planetEnemyShips[planet.entity_id] > 0) return o;
	if (planetMyShips[planet.entity_id] >= planet.docking_spots) return o;
	
	double v = 0;
	if (ship.can_dock(planet)) {
		v = 2500;
		// if (planetAllies[planet.entity_id] >= planetEnemies[planet.entity_id] + 2 && planetEnemies[planet.entity_id] <= 2 && closestEnemyShip[ship.entity_id] > 20) v += 2000;
	} else {
		v = 2000 - ship.location.get_distance_to(planet.location) + planet.radius + planetValue[planet.entity_id];
	}
	o.value = v;
	
	return o;
}

int totalAttackMiners = 0;
int totalHitAndRunners = 0;

Order attackOrder(const Ship& ship, const Ship& eship, EntityId eid, double minValue = 0) {
	Order o;
	if (enemyFollowers[eid] >= maxFollowers[eid]) return o;
	
	double dist = ship.location.get_distance_to(eship.location);
	double v = 1000 - dist;
	if (dist < 45) v += 2000;
	if (aggressiveShips.count(eid)) v += 15;
	if (eship.docking_status != ShipDockingStatus::Undocked) v += 40;
	// if (m.ships[player_id].S >= 10 && totalHitAndRunners == 0 && eship.docking_status != ShipDockingStatus::Undocked) v += 10000;
	
	if (v <= minValue) return o;
	
	
	if (false && v > 10000) {
		o.type = OrderType::HitAndRun;
	} else if (false && aggressiveShips.count(eid) && minerDefenders[aggressiveShips[eid]] <= 1) {
		o.type = OrderType::DefendMiner;
	} else if (eship.docking_status == ShipDockingStatus::Undocked) {
		o.type = OrderType::AttackShip;
	} else {
		// o.type = totalHitAndRunners == 0 ? OrderType::HitAndRun : OrderType::AttackMiner;
		// o.type = OrderType::HitAndRun;
		o.type = OrderType::AttackMiner;
	}
	o.ship = ship.entity_id;
	o.target = eid;
	o.value = v;
	return o;
}

Order hideOrder(const Ship& ship, int cx, int cy) {
	Location loc(cx == 0 ? 1 : m.map_width - 1, cy == 0 ? 1 : m.map_height - 1);
	double dist = ship.location.get_distance_to(loc);
	
	Order o;
	o.ship = ship.entity_id;
	o.cornerx = cx;
	o.cornery = cy;
	o.type = OrderType::Hide;
	o.value = 5000 - dist;
	return o;
}

void recalcOrder(Order& o) {
	const Ship& ship = m.get_ship(player_id, o.ship);
	if (o.type == OrderType::Colonize) {
		o = colonizeOrder(ship, m.planets[o.planet]);
	} else if (o.type == OrderType::AttackShip || o.type == OrderType::AttackMiner || o.type == OrderType::DefendMiner || o.type == OrderType::HitAndRun) {
		Ship eship = *enemyShips[o.target];
		o = attackOrder(ship, eship, o.target);
	} else if (o.type == OrderType::Hide) {
		o = hideOrder(ship, o.cornerx, o.cornery);
	} else {
		assert(false);
	}
}

Move execOrder(Order &o) {
	const Ship& ship = m.get_ship(player_id, o.ship);
	
	if (o.type == OrderType::Colonize) {
		Planet& planet = m.planets[o.planet];
		if (ship.can_dock(planet)) {
			Move mv = Move::dock(ship.entity_id, planet.entity_id);
			mv.evasion = Evasion::None;
			return mv;
		} else {
			Move mv = move_to(ship, planet.location);
			mv.evasion = Evasion::None;
			return mv;
		}
		
	} else if (o.type == OrderType::AttackShip) {
		Ship eship = *enemyShips[o.target];
		double dist = ship.location.get_distance_to(eship.location);
		Move mv = move_to(ship, eship.location, MAX_SPEED);
		mv.evasion = Evasion::Small;
		return mv;
		
	} else if (o.type == OrderType::AttackMiner) {
		Ship eship = *enemyShips[o.target];
		double dist = ship.location.get_distance_to(eship.location);
		Move mv = move_to(ship, eship.location, MAX_SPEED, 4.45);
		mv.evasion = Evasion::Medium;
		return mv;
		
	} else if (o.type == OrderType::HitAndRun) {
		Ship eship = *enemyShips[o.target];
		double dist = ship.location.get_distance_to(eship.location);
		Move mv = move_to(ship, eship.location, MAX_SPEED, 5.05, true);
		mv.evasion = Evasion::None;
		return mv;
		
	// } else if (o.type == OrderType::DefendMiner) {
		// Ship aship = m.get_ship(player_id, aggressiveShips[o.target]);
		// double dist = ship.location.get_distance_to(aship.location);
		// Move mv = Move::stop(ship.entity_id);
		// REP(tries, 10) {
			// auto nav = move_to(ship, aship.location + Location(rng.nextDouble(-2, 2), rng.nextDouble(-2, 2)), max(0.0, min(dist + 1.25, MAX_SPEED)));
			// if (nav.Y) {
				// mv = nav.X;
				// break;
			// }
		// }
		// mv.evasion = Evasion::None;
		// return mv;		
		
	} else if (o.type == OrderType::Hide) {
		Location loc = Location(o.cornerx == 0 ? 1 : m.map_width - 1, o.cornery == 0 ? 1 : m.map_height - 1);
		double dist = ship.location.get_distance_to(loc);
		Move mv = move_to(ship, loc, min(dist, MAX_SPEED), 0.0, true);
		mv.evasion = Evasion::None;
		return mv;
		
	} else {
		assert(false);
	}
}

int main() {
	ADD_TIMER(Parse);
	ADD_TIMER(PreProcess);
	ADD_TIMER(Orders);
	ADD_TIMER(Moves);
	ADD_TIMER(Evasion);
	ADD_TIMER(AntiCollision);
	ADD_TIMER(AvoidOOB);
	
	ios_base::sync_with_stdio(false);
    const Metadata metadata = initialize("Psyho");
    player_id = metadata.player_id;

    const Map& initial_map = metadata.initial_map;
	
	VC<Planet> oplanets = initial_map.planets;

    ostringstream initial_map_intelligence;
    initial_map_intelligence
            << "width: " << initial_map.map_width
            << "; height: " << initial_map.map_height
            << "; players: " << initial_map.ship_map.size()
            << "; my ships: " << initial_map.ship_map.at(player_id).size()
            << "; planets: " << initial_map.planets.size();
    Log::log(initial_map_intelligence.str());

	turn = 0;
	while (true) {
		turn++;
		
		timerParse.start();
        m = in::get_map();
		m.my_id = player_id;
		timerParse.stop();
		Log::clear();
		
		double startTime = getTime();
		
		int players_no = m.ships.S;
		
		timerPreProcess.start();
		
		//Calc closestEnemyShip
		closestEnemyShip.clear();
		for (Ship& s : m.ships[player_id]) {
			closestEnemyShip[s.entity_id] = 1e9;
			for (auto& ps : m.ships) if (ps.X != player_id) for (Ship& es : ps.Y)
				closestEnemyShip[s.entity_id] = min(closestEnemyShip[s.entity_id], s.location.dist(es.location));
		}
		
		//Calc planetAllies & planetEnemies
		planetAllies.clear();
		planetEnemies.clear();
		for (Planet& p : m.planets) for (auto& ps : m.ships) for (Ship& s : ps.Y) {
			if (p.location.dist_sq(s.location) > 60 * 60) continue;
			if (s.docked()) continue;
			if (ps.X == player_id) {
				planetAllies[p.entity_id]++;
			} else {
				planetEnemies[p.entity_id]++;
			}
		}
		
		//Calc spawnedShips
		spawnedShips.clear();
		for (Planet& p : m.planets) {
			int docked = 0;
			if (p.owner_id != -1) {
				for (EntityId& eid : p.docked_ships) {
					const Ship& ship = m.get_ship(p.owner_id, eid);
					docked += ship.docking_status == ShipDockingStatus::Docked || ship.docking_status == ShipDockingStatus::Docking && ship.docking_progress == 1;
				}
			}
			if (docked * BASE_PRODUCTIVITY + p.current_production >= 72)
				spawnedShips.PB(MP(getSpawningPoint(p), p.owner_id));
		}
		
			
				
		
		//Calc maxFollowers
		maxFollowers.clear();
		for (auto& ps : m.ships) if (ps.X != player_id) for (Ship& s : ps.Y) {
			int v = turn < 60 ? 3 : 5;
			bool alone = true;
			for (Ship& s2 : ps.Y) if (s.entity_id != s2.entity_id && s.location.dist_sq(s2.location) < 50 * 50) alone = false;
			if (alone) v = 2;
			maxFollowers[s.entity_id] = v;
		}
		
		
		//Create enemyShips map
		enemyShips.clear();
		for (auto& ps : m.ships) for (Ship& ship : ps.Y) enemyShips[ship.entity_id] = &ship;
		
		//Calc Aggressive Units
		aggressiveShips.clear();
		for (Ship& ship : m.ships[player_id]) if (ship.docking_status != ShipDockingStatus::Undocked) {
			for (auto ps : m.ships) if (ps.X != player_id) for (Ship& eship : ps.Y) if (eship.docking_status == ShipDockingStatus::Undocked) {
				double dist = ship.location.get_distance_to(eship.location);
				if (dist < 25) {
					int eid = eship.entity_id;
					if (aggressiveShips.count(eid) == 0 || dist < m.get_ship(player_id, aggressiveShips[eid]).location.get_distance_to(eship.location))
						aggressiveShips[eid] = ship.entity_id;
				}
			}
		}
		
		//Calc MyShips & EnemyShips
		planetMyShips.clear();
		planetEnemyShips.clear();
		for (auto& ps : m.ships) for (Ship& ship : ps.Y) {
			if (ship.docking_status == ShipDockingStatus::Undocked) continue;
			EntityId planetId = ship.docked_planet;
			if (ps.X == player_id) {
				planetMyShips[planetId]++;
			} else {
				planetEnemyShips[planetId]++;
			}
		}
		
		//Calc Planet Value
		planetValue.clear();
		Location centerMass;
		int planetsOwned = 0;
		for (Planet& p : m.planets) if (p.owned) {
			centerMass += p.location;
			planetsOwned++;
		}
		if (planetsOwned) centerMass /= planetsOwned;
		
		for (Planet& p : m.planets) {
			double v = 0;
			
			double dist_from_origin = Location(m.map_width / 2, m.map_height / 2).get_distance_to(p.location);
			// v += dist_from_origin * (players_id == 4 ? 0.1 : -0.25);
			v += dist_from_origin * (players_no == 4 ? 0.1 : 0);
			
			double dist_from_mass_center = planetsOwned ? p.location.get_distance_to(centerMass) : 0.0;
			if (players_no == 4) v -= dist_from_mass_center * 0.1;
			
			if (players_no == 4 && dist_from_origin < 30) v -= 25;
			
			// double dist_to_enemy = 1e9;
			// for (Planet& p2 : m.planets) if (planetEnemyShips[p2.entity_id] > 0)
				// dist_to_enemy = min(dist_to_enemy, p.location.get_distance_to(p2.location));
			// if (dist_to_enemy > 1e6) dist_to_enemy = 0;
			// v += dist_to_enemy * 0.3;
			
			planetValue[p.entity_id] = v;
		}
		
		//Calc Going Down
		bool goingDown = false;
		ZERO(holdCorners);
		int totalShips = 0;
		for (auto& ps : m.ships) totalShips += ps.Y.S;
		if (players_no > 2 && turn > 40 && m.ships[player_id].S < totalShips * 0.1) goingDown = true;
		
		timerPreProcess.stop();
		
		// //NoColonize
		// static bool noColonize = false;
		// static int noColonizeTurn = 0;
		// if (turn < 20) {
			// double maxShipDist = 0;
			// bool allUndocked = true;
			// REP(i, m.ships[player_id].S) {
				// REP(j, i) maxShipDist = max(maxShipDist, m.ships[player_id][i].location.dist(m.ships[player_id][j].location));
				// allUndocked &= m.ships[player_id][i].docking_status == ShipDockingStatus::Undocked;
			// }
			// for (auto& ps : m.ships) if (ps.X != player_id) {
				// double maxEnemyDist = 0;
				// for (Ship& eship : ps.Y) for (Ship& ship : m.ships[player_id]) maxEnemyDist = max(maxEnemyDist, ship.location.dist(eship.location));
				// int docking_progress = 0;
				// for (Ship& eship : ps.Y) docking_progress = max(docking_progress, eship.docking_progress);
				// // if (allUndocked && maxShipDist < 10 && turn < 20 && m.ships[player_id].S == 3 && maxEnemyDist < 35 + docking_progress * 8)
				// if (allUndocked && maxShipDist < 10 && turn < 20 && m.ships[player_id].S == 3 && maxEnemyDist < 70)
					// if (!noColonize) {
						// Log::log("No Colonize!!!");
						// noColonize = true;
						// noColonizeTurn = turn;
					// }
			// }
		// }
		// noColonize = false;
		
		timerOrders.start();
		//Generate Orders
		shipUsed.clear();
		enemyFollowers.clear();
		minerDefenders.clear();
		VC<Order> orders;
		VC<Order> so(m.ships[player_id].S);
		Log::log("[Phase Start] Orders");
		
		totalAttackMiners = 0;
		totalHitAndRunners = 0;
		int ordersSaved = 0;
		int ordersCalced = 0;
		while (true) {
			bool late = getTime() - startTime > 1.0;
			
			Order bo;
			bo.type = OrderType::Invalid;
			bo.value = 0;
			
			REP(i, m.ships[player_id].S) {
				Ship& ship = m.ships[player_id][i];
				if (shipUsed[ship.entity_id]) continue;
				if (ship.docking_status != ShipDockingStatus::Undocked)	continue;
				
				if (!late && so[i].value > 0) {
					double prevValue = so[i].value;
					recalcOrder(so[i]);
					if (prevValue == so[i].value) {
						ordersSaved++;
						if (so[i].value > bo.value)
							bo = so[i];
						continue;
					} 
				}
				ordersCalced++;
				so[i] = Order();
				
				for (Planet& planet : m.planets) {
					// if (noColonize && turn < noColonizeTurn + 10) continue;
					Order o = colonizeOrder(ship, planet);
					if (o.value > so[i].value)
						so[i] = o;
				}
				
				for (auto ps : m.ships) if (ps.X != player_id) for (Ship& eship : ps.Y) {
					Order o = attackOrder(ship, eship, eship.entity_id, so[i].value);
					if (o.value > so[i].value)
						so[i] = o;
				}
				
				if (goingDown) REP(cx, 2) REP(cy, 2) if (!holdCorners[cx][cy]) {
					Order o = hideOrder(ship, cx, cy);
					if (o.value > so[i].value)
						so[i] = o;
				}
				
				if (late && so[i].value > 0) {
					bo = so[i];
					orders.PB(bo);
					shipUsed[bo.ship] = true;
					if (bo.planet >= 0) planetMyShips[bo.planet]++;
					if (bo.target >= 0) enemyFollowers[bo.target]++;
					if (bo.cornerx >= 0) holdCorners[bo.cornerx][bo.cornery] = true;
					if (bo.type == OrderType::DefendMiner) minerDefenders[aggressiveShips[bo.target]]++;
					if (bo.type == OrderType::AttackMiner) totalAttackMiners++;
					if (bo.type == OrderType::HitAndRun) totalHitAndRunners++;
					if (bo.type == OrderType::Colonize && m.get_my_ship(bo.ship).can_dock(m.planets[bo.planet])) {
						const Ship& s = m.get_my_ship(bo.ship);
						for (Planet& p : m.planets) if (s.location.dist_sq(p.location) < 60 * 60) planetAllies[p.entity_id]--;
					}
				}
				
				if (so[i].value > bo.value)
					bo = so[i];
			}
			
			if (late || bo.type == OrderType::Invalid)
				break;
			
			
			orders.PB(bo);
			shipUsed[bo.ship] = true;
			if (bo.planet >= 0) planetMyShips[bo.planet]++;
			if (bo.target >= 0) enemyFollowers[bo.target]++;
			if (bo.cornerx >= 0) holdCorners[bo.cornerx][bo.cornery] = true;
			if (bo.type == OrderType::DefendMiner) minerDefenders[aggressiveShips[bo.target]]++;
			if (bo.type == OrderType::AttackMiner) totalAttackMiners++;
			if (bo.type == OrderType::HitAndRun) totalHitAndRunners++;
			if (bo.type == OrderType::Colonize && m.get_my_ship(bo.ship).can_dock(m.planets[bo.planet])) {
				const Ship& s = m.get_my_ship(bo.ship);
				for (Planet& p : m.planets) if (s.location.dist_sq(p.location) < 60 * 60) planetAllies[p.entity_id]--;
			}
		}
		timerOrders.stop();
		
		Log::log("Orders Saved: " + i2s(ordersSaved));
		Log::log("Orders Calced: " + i2s(ordersCalced));
		
		// Convert to Hit And Run
		for (Order &o : orders) if (o.type == OrderType::AttackMiner) {
			bool alone = true;
			Location loc = m.get_my_ship(o.ship).location;
			for (Ship &s : m.ships[player_id]) if (s.entity_id != o.ship) {
				alone &= loc.dist_sq(s.location) > 30 * 30;
			}
			if (alone) o.type = OrderType::HitAndRun;
		}
		
		
		timerMoves.start();
		//Create Moves
		Log::log("[Phase Start] Create Moves");
		VC<Move> moves;
		for (Order &o : orders) {
			Move mv = execOrder(o);
			mv.move_thrust = max(0.0, mv.move_thrust);
			moves.PB(mv);
			m.get_my_ship(mv.ship_id).move = mv;
			if (LOG_MOVES) {
				Location loc = m.get_ship(player_id, mv.ship_id).location;
				Log::log("[Order] " + o.tostring() +  " [Move] Type: " + i2s((int)mv.type) + " Evasion: " + i2s((int)mv.evasion) + " Thrust: " + i2s(mv.move_thrust) + " Angle: " + i2s(mv.move_angle_deg) + " Pos: " + loc.tostring() + " NPos: " + (loc + mv.get_velocity()).tostring());
			}
		}
		timerMoves.stop();
		
		timerEvasion.start();
		//Evasion
		Log::log("[Phase Start] Evasion");
		REP(i, moves.S) {
			if (moves[i].type != MoveType::Thrust) continue;
			if (moves[i].evasion == Evasion::None) continue;
			
			Ship& ship = m.get_my_ship(moves[i].ship_id);
			int allies = 0;
			int enemies = 0;
			double ex = 0;
			double ey = 0;
			
			Location loc = ship.location;
			Location tloc = loc + moves[i].get_velocity() / 2;
			
			double closest_enemy = 1e9;
			for (auto ps : m.ships) for (Ship& eship : ps.Y) if (eship.entity_id != ship.entity_id || ps.X != player_id) {
				bool docked = eship.docking_status != ShipDockingStatus::Undocked;
				Location eloc = eship.location;
				double distance = loc.dist(eloc);
				double target_distance = tloc.dist(eloc);
				// if (ps.X == player_id && !docked && tloc.dist(eship.location + eship.move.get_velocity()) < 7.5) {
				if (distance < 12.5 && ps.X == player_id && !docked) {
					allies++;
				} else if (target_distance < 12.5 && ps.X == player_id && docked) {
					allies++;
				} else if (target_distance < 12.5 && ps.X != player_id && !docked) {
					enemies++;
					closest_enemy = min(closest_enemy, ship.location.dist(eship.location));
					ex += eship.location.pos_x;
					ey += eship.location.pos_y;
				}
			}
			
			for (auto spawn : spawnedShips) if (spawn.Y != player_id && tloc.dist(spawn.X) < 6.0) {
				enemies++;
				closest_enemy = min(closest_enemy, ship.location.dist(spawn.X));
				ex += spawn.X.pos_x;
				ey += spawn.X.pos_y;
			}
			
			
			if (enemies > allies+1 || enemies > allies && moves[i].evasion == Evasion::Medium || enemies > 0 && moves[i].evasion == Evasion::Full) {
				Location tloc = ship.location + (ship.location - Location(ex, ey) / enemies).normalize() * 1000;
				Log::log("Evade: " + i2s(moves[i].ship_id));
				// Move mv = move_to(ship, tloc, MAX_SPEED, 0.0, moves[i].evasion == Evasion::Full);
				Move mv = move_to(ship, tloc, MAX_SPEED, 0.0, true, false);
				if (mv.move_thrust >= 0) {
					moves[i] = mv;
					ship.move = moves[i];
				}
			}
		}
		timerEvasion.stop();
		
		//GiveUp?
		bool giveUp = false;
		giveUp |= GIVE_UP_LOSING && m.ships[player_id].S < totalShips * 0.3;
		if (giveUp)	REP(i, 2) moves.PB(Move::stop(m.ships[player_id][0].entity_id));
		
		//Print Timers
		static bool prevGameEnd = false;
		bool gameEnd = false;
		for (auto& ps : m.ships) if (ps.Y.S >= totalShips * 0.9) gameEnd = true;
		VI ownedPlanets(players_no);
		for (Planet& p : m.planets) if (p.owner_id != -1) ownedPlanets[p.owner_id]++;
		REP(i, players_no) if (ownedPlanets[i] >= m.planets.S - 2) gameEnd = true;
		if (!prevGameEnd && gameEnd) {
			prevGameEnd = true;
			for (Timer* t : timerPool)
				Log::log(t->tostring());
		}
		
		//Sanity Check
		// static map<EntityId, Location> futurePos;
		// for (Move &mv : moves) if (futurePos.count(mv.ship_id) && futurePos[mv.ship_id].dist(m.get_my_ship(mv.ship_id).location) > 1e-6) assert(false);
		// if (rng.next(200) == 0) assert(false);
		// futurePos.clear();
		// for (Move &mv : moves) futurePos[mv.ship_id] = m.get_my_ship(mv.ship_id).location + mv.get_velocity();
		// REP(i, m.planets.S) if (m.planets[i].health != oplanets[i].health) assert(false);
		
		
		Log::log("Total Moves: " + i2s(moves.S));
		
		Log::log("[Done]");
        if (!out::send_moves(moves)) {
            Log::log("send_moves failed; exiting");
            break;
        }
    }
}
