// Author: Psyho
// Blog: http://psyho.gg/
// Twitter: https://twitter.com/fakepsyho

#include "hlt/hlt.hpp"
#include "hlt/navigation.hpp"
#include <bits/stdc++.h>
#include <sys/time.h>

using namespace std;
using namespace hlt;
using namespace hlt::navigation;

#define INLINE   inline __attribute__ ((always_inline))
#define NOINLINE __attribute__ ((noinline))

#define ALIGNED __attribute__ ((aligned(16)))

#define likely(x)   __builtin_expect(!!(x),1)
#define unlikely(x) __builtin_expect(!!(x),0)

#define SSELOAD(a)     _mm_load_si128((__m128i*)&a)
#define SSESTORE(a, b) _mm_store_si128((__m128i*)&a, b)

#define FOR(i,a,b)  for(int i=(a);i<(b);++i)
#define REP(i,a)    FOR(i,0,a)
#define ZERO(m)     memset(m,0,sizeof(m))
#define ALL(x)      x.begin(),x.end()
#define PB          push_back
#define S           size()
#define byte        unsigned char
#define LL          long long
#define ULL         unsigned long long
#define LD          long double
#define MP          make_pair
#define X           first
#define Y           second
#define VC          vector
#define PII         pair<int, int>
#define PDD         pair<double, double>
#define VI          VC<int>
#define VVI         VC<VI>
#define VVVI        VC<VVI>
#define VPII        VC<PII>
#define VVPII       VC<VPII>
#define VVVPII      VC<VVPII>
#define VD          VC<double>
#define VVD         VC<VD>
#define VVVD        VC<VVD>
#define VPDD        VC<PDD>
#define VVPDD       VC<VPDD>
#define VVVPDD      VC<VVPDD>
#define VS          VC<string>
#define VVS         VC<VS>
#define VVVS        VC<VVS>
#define DB(a)       cerr << #a << ": " << (a) << endl;

template<class A, class B> ostream& operator<<(ostream &os, pair<A,B> &p) {os << "(" << p.X << "," << p.Y << ")"; return os;}
template<class A, class B, class C> ostream& operator<<(ostream &os, tuple<A,B,C> &p) {os << "(" << get<0>(p) << "," << get<1>(p) << "," << get<2>(p) << ")"; return os;}
template<class T> ostream& operator<<(ostream &os, VC<T> &v) {os << "{"; REP(i, v.S) {if (i) os << ", "; os << v[i];} os << "}"; return os;}
template<class T> ostream& operator<<(ostream &os, set<T> &s) {VC<T> vs(ALL(s)); return os << vs;}
template<class A, class B> ostream& operator<<(ostream &os, map<A, B> &m) {VC<pair<A,B>> vs; for (auto &x : m) vs.PB(x); return os << vs;}
template<class T> string i2s(T x) {ostringstream o; if (floor(x) == x) o << (int)x; else o << x; return o.str();}
VS splt(string s, char c = ' ') {VS all; int p = 0, np; while (np = s.find(c, p), np >= 0) {all.PB(s.substr(p, np - p)); p = np + 1;} all.PB(s.substr(p)); return all;}

double getTime() {
	timeval tv;
	gettimeofday(&tv, NULL);
	return tv.tv_sec + tv.tv_usec * 1e-6;
}

struct RNG {
    unsigned int MT[624];
    int index;
	
	RNG(int seed = 1) {
		init(seed);
	}
    
    void init(int seed = 1) {
        MT[0] = seed;
        FOR(i, 1, 624) MT[i] = (1812433253UL * (MT[i-1] ^ (MT[i-1] >> 30)) + i);
        index = 0;
    }
    
    void generate() {
        const unsigned int MULT[] = {0, 2567483615UL};
        REP(i, 227) {
            unsigned int y = (MT[i] & 0x8000000UL) + (MT[i+1] & 0x7FFFFFFFUL);
            MT[i] = MT[i+397] ^ (y >> 1);
            MT[i] ^= MULT[y&1];
        }
        FOR(i, 227, 623) {
            unsigned int y = (MT[i] & 0x8000000UL) + (MT[i+1] & 0x7FFFFFFFUL);
            MT[i] = MT[i-227] ^ (y >> 1);
            MT[i] ^= MULT[y&1];
        }
        unsigned int y = (MT[623] & 0x8000000UL) + (MT[0] & 0x7FFFFFFFUL);
        MT[623] = MT[623-227] ^ (y >> 1);
        MT[623] ^= MULT[y&1];
    }
    
    unsigned int rand() {
        if (index == 0) {
            generate();
        }
        
        unsigned int y = MT[index];
        y ^= y >> 11;
        y ^= y << 7  & 2636928640UL;
        y ^= y << 15 & 4022730752UL;
        y ^= y >> 18;
        index = index == 623 ? 0 : index + 1;
        return y;
    }
    
    INLINE int next() {
        return rand();
    }
    
    INLINE int next(int x) {
        return rand() % x;
    }
    
    INLINE int next(int a, int b) {
        return a + (rand() % (b - a));
    }
    
    INLINE double nextDouble() {
        return (rand() + 0.5) * (1.0 / 4294967296.0);
    }
};

PlayerId player_id;
Map m;

bool expected_collision(Move &m1, Move &m2, int steps = 50) {
	const double COLLISION_DIST = 1.25;
	const Ship& s1 = m.get_ship(player_id, m1.ship_id);
	const Ship& s2 = m.get_ship(player_id, m2.ship_id);
	double d = s1.location.get_distance_to(s2.location);
	if (d > 17) return false;
	if (d > m1.move_thrust + m2.move_thrust + 3) return false;
	double rad1 = m1.move_angle_deg / 180.0 * M_PI;
	double rad2 = m2.move_angle_deg / 180.0 * M_PI;
	double vx1 = m1.move_thrust * cos(rad1);
	double vy1 = m1.move_thrust * sin(rad1);
	double vx2 = m2.move_thrust * cos(rad2);
	double vy2 = m2.move_thrust * sin(rad2);
	FOR(step, 1, steps+1) {
		double ratio = 1.0 * step / steps+1;
		double x1 = s1.location.pos_x + vx1 * ratio;
		double y1 = s1.location.pos_y + vy1 * ratio;
		double x2 = s2.location.pos_x + vx2 * ratio;
		double y2 = s2.location.pos_y + vy2 * ratio;
		if ((x1-x2)*(x1-x2)+(y1-y2)*(y1-y2) < COLLISION_DIST * COLLISION_DIST) return true;
	}
	return false;
}


int main() {
    const Metadata metadata = initialize("Psyho");
    player_id = metadata.player_id;

    const Map& initial_map = metadata.initial_map;

    ostringstream initial_map_intelligence;
    initial_map_intelligence
            << "width: " << initial_map.map_width
            << "; height: " << initial_map.map_height
            << "; players: " << initial_map.ship_map.size()
            << "; my ships: " << initial_map.ship_map.at(player_id).size()
            << "; planets: " << initial_map.planets.size();
    Log::log(initial_map_intelligence.str());

    
	while (true) {
		double startTime = getTime();
		
		vector<Move> moves;
        m = in::get_map();
		
		map<EntityId, int> planetMyShips;
		map<EntityId, int> planetEnemyShips;
		
		for (auto ps : m.ships) for (Ship& ship : ps.Y) {
			if (ship.docking_status == ShipDockingStatus::Undocked) continue;
			EntityId planetId = ship.docked_planet;
			if (ps.X == player_id) {
				planetMyShips[planetId]++;
			} else {
				planetEnemyShips[planetId]++;
			}
		}
		
		map<EntityId, bool> shipUsed;
		
		while (true) {
			bool late = getTime() - startTime > 0.5;
			
			double bv = 0;
			Move bm = Move::noop();
			int bp = -1;
			
			for (Ship& ship : m.ships[player_id]) {
				if (shipUsed[ship.entity_id]) continue;
				
				if (ship.docking_status != ShipDockingStatus::Undocked)
					continue;
				
				if (late) {
					bv = 0;
					bm = Move::noop();
					bp = -1;
				}
				
				for (Planet& planet : m.planets) {
					if (planetEnemyShips[planet.entity_id] > 0) continue;
					if (planetMyShips[planet.entity_id] >= planet.docking_spots) continue;
					
					double av = 0;
					Move am = Move::noop();
					
					auto move = navigate_ship_to_dock(m, ship, planet, constants::MAX_SPEED);
					if (move.Y) {
						am = move.X;
						av = 2000 - ship.location.get_distance_to(planet.location);
					}
					
					if (ship.can_dock(planet)) {
						am = Move::dock(ship.entity_id, planet.entity_id);
						av = 2000;
					}
					
					if (av > bv) {
						bm = am;
						bv = av;
						bp = planet.entity_id;
					}
					
				}
				
				for (auto ps : m.ships) if (ps.X != player_id) for (Ship& eship : ps.Y) {
					
					double dist = ship.location.get_distance_to(eship.location);
					double av = 1000 - dist;
					if (dist < 30) av += 2000;
					if (eship.docking_status != ShipDockingStatus::Undocked) av += 40;
					
					if (av > bv) {
						auto nav = navigate_ship_towards_target(m, ship, eship.location, max(0, min((int)(dist - 1), constants::MAX_SPEED)), true, constants::MAX_NAVIGATION_CORRECTIONS, M_PI / 180.0);
						if (nav.Y) {
							bv = av;
							bm = nav.X;
							bp = -1;
						}
					}
				}
				
				if (late) {
					moves.PB(bm);
				}
			}
			
			if (late) break;
			
			if (bm.type == MoveType::Noop)
				break;
			
			moves.PB(bm);
			shipUsed[bm.ship_id] = true;
			if (bp != -1) planetMyShips[bp]++;
		}
		
		/*
		//Enemy evasion
		REP(i, moves.S) {
			if (moves[i].type != MoveType::Thrust) continue;
			
			Location
			int allies = 0;
			int enemies = 0;
		}*/
		
		//Anti-collision post process
		REP(i, moves.S) {
			if (getTime() - startTime > 1.5) break;
			
			if (moves[i].type != MoveType::Thrust) continue;
			if (moves[i].move_thrust == 0) continue;
			while (moves[i].move_thrust > 0) {
				bool succ = true;
				REP(j, i) {
					if (expected_collision(moves[i], moves[j])) {
						moves[i].move_thrust--;
						succ = false;
						break;
					}
				}
				if (succ) break;
			}
		}

        if (!out::send_moves(moves)) {
            Log::log("send_moves failed; exiting");
            break;
        }
    }
}
